Step1: Find the requirements.txt and install pip files using the terminal.
Step2: Open the extracted file on the IDE present on the machine.
Step3: Find and run the main.py file.
Step4: After the execution of the file is completed find the link of server from the terminal to run the web app.


Requirements
pip install flask
pip install Flask-SQLAlchemy
pip install flask-login

if any No Module found error,
pip install <module name>

Run the app
python main.py


Working of the App
We have 2 categories of users

-Admin

Use an email with domain as '@admin' while registering
Add movies to the database
Register his theater and add shows in his theater



-Normal User

Book shows


